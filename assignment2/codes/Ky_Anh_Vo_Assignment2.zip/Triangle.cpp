#include "Triangle.hpp"

#include <algorithm>
#include <array>

Triangle::Triangle() {
  v[0] << 0, 0, 0;
  v[1] << 0, 0, 0;
  v[2] << 0, 0, 0;

  color[0] << 0.0, 0.0, 0.0, 1.0;
  color[1] << 0.0, 0.0, 0.0, 1.0;
  color[2] << 0.0, 0.0, 0.0, 1.0;

  tex_coords[0] << 0.0, 0.0;
  tex_coords[1] << 0.0, 0.0;
  tex_coords[2] << 0.0, 0.0;
}

void Triangle::setVertex(int ind, Vector3f ver) { v[ind] = ver; }
void Triangle::setNormal(int ind, Vector3f n) { normal[ind] = n; }
void Triangle::setColor(int ind, float r, float g, float b, float alpha) {
  if ((r < 0.0) || (r > 255.) || (g < 0.0) || (g > 255.) || (b < 0.0) ||
      (b > 255.)) {
    fprintf(stderr, "ERROR! Invalid color values");
    fflush(stderr);
    exit(-1);
  }
  if ((alpha < 0.0) || (alpha > 1.0)) {
    fprintf(stderr, "ERROR! Invalid alpha value");
    fflush(stderr);
    exit(-1);
  }

  color[ind] = Vector4f((float)r / 255., (float)g / 255., (float)b / 255., alpha);
  return;
}
void Triangle::setTexCoord(int ind, float s, float t) {
  tex_coords[ind] = Vector2f(s, t);
}

std::array<Vector4f, 3> Triangle::toVector4() const {
  std::array<Eigen::Vector4f, 3> res;
  std::transform(std::begin(v), std::end(v), res.begin(), [](auto& vec) {
    return Eigen::Vector4f(vec.x(), vec.y(), vec.z(), 1.f);
  });
  return res;
}
